import { Routes } from '@angular/router';
import { MatselectValidationComponent } from './matselect-validation/matselect-validation.component';

export const routes: Routes = [
    {path: '',component: MatselectValidationComponent}
];
