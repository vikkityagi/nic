import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, NG_VALUE_ACCESSOR, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule} from '@angular/material/input';
import { MatSelectModule} from '@angular/material/select';

@Component({
  selector: 'app-matselect-validation',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule,MatInputModule,MatSelectModule],
  templateUrl: './matselect-validation.component.html',
  styleUrl: './matselect-validation.component.scss'
})
export class MatselectValidationComponent {

  myForm:any = FormGroup;
  cities: any[] = [];



  constructor(private fb:FormBuilder){

    this.cities = [{id:1,name:'Delhi'},{id:2,name:'Noida'},{id:3,name:'bihar'}];

    this.init();

  }

  init(){
    this.myForm = this.fb.group({
      array: []
    })
  }

  public onSelect(event: any):void{
    console.log(event.value);
    console.log(this.myForm.get('array').value);
    console.log();
  }

  public onDisabled(){
    return this.myForm.get('array').value?.length > 1;
  }

}
