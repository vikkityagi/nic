import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MatselectValidationComponent } from './matselect-validation.component';

describe('MatselectValidationComponent', () => {
  let component: MatselectValidationComponent;
  let fixture: ComponentFixture<MatselectValidationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MatselectValidationComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(MatselectValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
