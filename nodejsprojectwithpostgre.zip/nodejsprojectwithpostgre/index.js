// index.js

const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// POST API endpoint to insert data into the database
app.post('/api/data', async (req, res) => {
  try {
    const data  = req.body;
    console.log(req.body);
    const query = 'INSERT INTO student (name) VALUES ($1) RETURNING *';
    await pool.query(query, [data.name]);
    res.status(201).json({ message: 'Data inserted successfully' });
  } catch (error) {
    console.error('Error inserting data:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
