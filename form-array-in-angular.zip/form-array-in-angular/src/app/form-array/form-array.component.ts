import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { provideNativeDateAdapter } from '@angular/material/core';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-form-array',
  standalone: true,
  imports: [ReactiveFormsModule, MatInputModule, CommonModule, MatFormFieldModule, MatDatepickerModule, MatIconModule, MatButtonModule],
  providers: [provideNativeDateAdapter()],
  templateUrl: './form-array.component.html',
  styleUrls: ['./form-array.component.css'] // Corrected from styleUrl to styleUrls
})
export class FormArrayComponent {
  firstFormGroup: FormGroup; // Corrected typing to FormGroup

  constructor(private fb: FormBuilder) {
    this.firstFormGroup = this.fb.group({
      items: this.fb.array([])
    });

    this.initFormGroup();
  }

  get items() {
    return this.firstFormGroup.get('items') as FormArray;
  }

  initFormGroup() {
    const itemGroup = this.fb.group({
      first_name: [''],
      last_name: [''],
      mobile: [''],
      start_date: [''],
      end_date: [''],
      dob: [''],
      address: ['']
    });

    this.items.push(itemGroup);
  }
}
