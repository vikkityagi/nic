import { Routes } from '@angular/router';
import { FormArrayComponent } from './form-array/form-array.component';

export const routes: Routes = [
    {path: '',redirectTo: '/home', pathMatch: 'full'},
    {path: 'home',component: FormArrayComponent}
];
