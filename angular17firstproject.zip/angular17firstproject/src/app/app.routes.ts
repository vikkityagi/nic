import { Routes } from '@angular/router';

export const routes: Routes = [
    { path: 'add', loadChildren: () => import('./add/add.module').then(m => m.AddModule) }
  ];
  


  