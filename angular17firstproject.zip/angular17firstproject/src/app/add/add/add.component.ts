import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-add',
  // standalone: true,
  // imports: [],
  templateUrl: './add.component.html',
  styleUrl: './add.component.scss'
})
export class AddComponent {

  addform: any = FormGroup;

  constructor(private fb:FormBuilder,
    private service: AuthService){
    this.init();
  }

  init(){
    this.addform = this.fb.group({
      name: [],
      dept:[]
    })
  }

  public onSubmit(){
    this.service.addStudent(this.addform.value).subscribe(data=>{
      this.addform.reset();
    },(error)=>{
      console.log("error ocurred"+error)
    })
  }

}
