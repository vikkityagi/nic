// import { Environment } from "./environment"

// export class apiUrlService {

//     if(this.Environment.production){

//     }
// }