import { Routes } from '@angular/router';
import { MyFormComponent } from './my-form/my-form.component';

export const routes: Routes = [
    {path:'form',component: MyFormComponent}
];
