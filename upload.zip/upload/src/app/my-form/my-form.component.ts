import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
// import { MatFormFieldModule} from '@angular/material/form-field';

@Component({
  selector: 'app-my-form',
  standalone: true,
  imports: [ReactiveFormsModule, MatInputModule,CommonModule],
  templateUrl: './my-form.component.html',
  styleUrl: './my-form.component.css'
})
export class MyFormComponent {

  studentsFormGroup: any = FormGroup;

  constructor(private fb: FormBuilder) {
    this.init();
  }

  init() {
    this.studentsFormGroup = this.fb.group({
      name: ['']
    })
  }

}
