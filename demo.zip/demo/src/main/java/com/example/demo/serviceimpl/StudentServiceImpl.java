package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;
import com.example.demo.repository.StudentRepo;
import com.example.demo.service.StudentService;

@Service
class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepo studentRepo;

    @Override
    public Student create(Student student) throws Exception {

        Student obj = new Student();
        obj.setName(student.getName());
        obj.setDept(student.getDept());

        Student newObj = studentRepo.save(obj);
        // TODO Auto-generated method stub
        return newObj;
    }

    @Override
    public Student get(long id) throws Exception {

        Optional<Student> stud = this.studentRepo.findById(id);

        if (!stud.isPresent()) {
            throw new Exception("Id not present");
        }
        Student sudent = stud.get();
        return sudent;
    }

    @Override
    public List<Student> list() throws Exception {

        List<Student> students = this.studentRepo.findAll();

        // TODO Auto-generated method stub
        return students;
    }

    @Override
    public Student edit(long id,Student student) throws Exception {

        Optional<Student> studentOptional = this.studentRepo.findById(id);
        if(!studentOptional.isPresent()){
            throw new Exception("id not found");
        }

        Student studentObj = studentOptional.get();

        studentObj.setName(student.getName());
        studentObj.setDept(student.getDept());

        Student newStudent = this.studentRepo.save(studentObj);

        // TODO Auto-generated method stub
        return newStudent;
    }

    @Override
    public Student delete(long id) throws Exception {

        Optional<Student> stud = this.studentRepo.findById(id);

        if (!stud.isPresent()) {
            throw new Exception("Id not present");
        }
        Student student = stud.get();

        this.studentRepo.deleteById(id);

        return student;
    }


}
