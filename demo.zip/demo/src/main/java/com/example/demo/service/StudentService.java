package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Student;

// @Service
public interface StudentService {
    
    Student create(Student student) throws Exception ;
    Student get(long id) throws Exception ;
    List<Student> list() throws Exception ;
    Student edit(long id,Student student) throws Exception ;
    Student delete(long id) throws Exception ;
}
