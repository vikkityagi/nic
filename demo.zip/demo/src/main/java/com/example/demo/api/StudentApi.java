package com.example.demo.api;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;

// @RestController
// @RequestMapping(value="api/v1")
public interface StudentApi {


    @RequestMapping(value="/students",method = RequestMethod.POST)
    public Student create(@RequestBody Student student);

    @RequestMapping(value="/student/{id}",method = RequestMethod.GET)
    public Student get(@PathVariable("id") long s_id);

    @RequestMapping(value="/students",method = RequestMethod.GET)
    public List<Student> list();

    @RequestMapping(value="/student/{id}",method = RequestMethod.PUT)
    public Student edit(@PathVariable("id") long s_id,@RequestBody() Student student);


    @RequestMapping(value="/student/{id}",method = RequestMethod.DELETE)
    public Student delete(@PathVariable("id") long s_id);
    
}
