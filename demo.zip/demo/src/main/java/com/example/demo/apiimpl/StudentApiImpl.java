package com.example.demo.apiimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.api.StudentApi;
import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;

@RestController
@CrossOrigin
public class StudentApiImpl implements StudentApi{

    @Autowired
    private StudentService studentService;

    @Override
    public Student create(Student student) {
        // TODO Auto-generated method stub
       try{
            Student newObj = this.studentService.create(student);
            return newObj;
       }catch(Exception e){
         e.printStackTrace();
       }
       return null;
    }

    @Override
    public Student get(long s_id){
      try{
        Student student = this.studentService.get(s_id);
        if(student!=null){
          return student;
        }
      }catch(Exception e){
        e.printStackTrace();
      }
      return null;
    }

    @Override
    public List<Student> list(){
      try{
        List<Student> students = this.studentService.list();
        if(students.size() != 0){
          return students;
        }
      }catch(Exception e){
        e.printStackTrace();
      }
      return null;
    }

    @Override
    public Student edit(long s_id,Student student){
      try{
        Student ediStudent = this.studentService.edit(s_id,student);
        if(ediStudent!=null){
          return ediStudent;
        }
      }catch(Exception e){
        e.printStackTrace();
      }
      return null;
    }

    @Override
    public Student delete(long s_id){
      try{
        Student student = this.studentService.delete(s_id);
        if(student!=null){
          return student;
        }
      }catch(Exception e){
        e.printStackTrace();
      }
      return null;
    }
    
}
