import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, RequiredValidator, Validators } from '@angular/forms';
import { conditionalRequiredValidator } from '../validators/required.validators';

@Component({
  selector: 'app-form1',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './form1.component.html',
  styleUrl: './form1.component.css'
})
export class Form1Component {

  form: any = FormGroup;
  checkBox = [
    { id: 1, name: 'Delhi' },
    { id: 2, name: 'Noida' },
    { id: 3, name: 'Meerut' }
  ]

  selectedCities:any = [];

  constructor(private fb: FormBuilder) {
    this.init();
  }

  init() {
    this.form = this.fb.group({
      name: [''],
      selectedOption: []
    })

    
  }

  public updateSelectedCities(id: number,event: any){
    if (event.target.checked) {
      this.selectedCities.push(id);
    } else {
      const index = this.selectedCities.indexOf(id);
      if (index !== -1) {
        this.selectedCities.splice(index, 1);
      }
    }
    console.log('selected city'+this.selectedCities)
  }

  public onRadioChange(event: Event){
    const selectedOption = (event.target as HTMLInputElement).value;
    this.isReuired(selectedOption);
  }

  isReuired(value: any){
    
      
    //   if (this.form.get('selectedOption').value) {
    //     // Set name control as required when selectedOption is true
    //     this.form.get('name').setValidators(Validators.required);
    //   } else {
    //     // Remove required validator when selectedOption is false
    //     this.form.get('name').clearValidators();
    //   }
    //   // Update the validation state of the name control
    //   this.form.get('name').updateValueAndValidity();
    // // });

    const selectedControl =  this.form.get('name');

    if(this.form.get('selectedOption').value){
      selectedControl.setValidators(conditionalRequiredValidator(value));
    }else{
      selectedControl.clearValidators();
    }

    selectedControl.updateValueAndValidity();


  }
  

}
