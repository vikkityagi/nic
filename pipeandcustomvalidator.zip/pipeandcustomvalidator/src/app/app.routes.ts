import { Routes } from '@angular/router';
import { FirstComponent } from './first/first.component';
import { Form1Component } from './form1/form1.component';

export const routes: Routes = [

    {path:'pipe',component: FirstComponent},
    {path: 'form',component: Form1Component}
];
