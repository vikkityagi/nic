import { Component} from '@angular/core';
@Component({
  selector: 'app-root',    
  templateUrl:'./app.component.html',  
  template: `Welcome to {{course}}`
})
export class AppComponent {
  salutation = "Hello";
  course = "Angular";
}