import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

  registerForm!: FormGroup;
  submitted!: boolean;

  constructor(private fb: FormBuilder) {
    this.initForm();

  }

  ngOnInit(): void {


  }

  initForm() {
    this.registerForm = this.fb.group({
      firstName: ['', { updateOn: 'blur', validators: [Validators.required] }],
      lastName: ['', Validators.required],
      address: this.fb.group({
        street: [],
        zip: [],
        city: []
      }),
      email: ['',this.validateEmail]
    });
  }

  validateEmail(c: FormControl): any {
    let EMAIL_REGEXP = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    return EMAIL_REGEXP.test(c.value) ? null : {
      emailInvalid: {
        message: "Invalid Format!"
      }
    };
  }

  onSubmit() {
    if (!this.registerForm.valid)
      return
  }

}
