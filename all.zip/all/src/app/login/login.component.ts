import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: any = FormGroup;
  isAuthenticated!: boolean;
  submitted = false;
  userName!: string;
  invalidCredentialMsg!: string;

  constructor(private fb:FormBuilder,
    private router: Router,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {

    this.init();
  }

  init(){
    this.loginForm = this.fb.group({
      username: [''],
      password: ['']
    })
  }

  public onFormSubmit(){

    const uname = this.loginForm.value.username;
    const pwd = this.loginForm.value.password;
    this.loginService
      .isUserAuthenticated(uname, pwd)
      .subscribe({next:(authenticated) => {
        if (authenticated) {
          this.router.navigate(['/welcome']);
        } else {
          this.invalidCredentialMsg = 'Invalid Credentials. Try again.';
        }
      }});
    
  }

}
