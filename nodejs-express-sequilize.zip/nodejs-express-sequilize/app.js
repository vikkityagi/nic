const express = require('express');
const app = express();
const swaggerUi = require('swagger-ui-express');
const fs = require("fs")
const YAML = require('yaml')
const port = 3001;
const sequelize = require('./sequelize');

const file = fs.readFileSync('./openapi.yaml', 'utf8')

const swaggerDocument = YAML.parse(file)

const treatmentController = require('./controllers/TreatmentController');
const complaintController = require('./controllers/ComplaintController');
const medicineController = require('./controllers/MedicineController');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));


// Middleware to parse JSON request bodies
app.use(express.json());


// Use controller modules to handle routes
app.use('/api/v3', treatmentController);
app.use('/api/v3', complaintController);
app.use('/api/v3', medicineController);




app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});

// sequelize.sync({ force: false })
//   .then(() => {
   
//   })
//   .catch(error => {
//     console.error('Unable to sync database:', error);
//   });
