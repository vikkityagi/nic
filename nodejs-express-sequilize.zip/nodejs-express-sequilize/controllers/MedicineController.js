const express = require('express');
const router = express.Router();
const MedicineModel = require('../models/MedicineModel');
const sequelize = require('../sequelize')

// Function to synchronize Sequelize with the database schema
async function syncDatabase() {
  try {
    await sequelize.sync({ force: false }); // Adjust force based on your needs
    console.log('Database synchronized successfully');
  } catch (error) {
    console.error('Error synchronizing database:', error);
    throw error; // Propagate the error if needed
  }
}

router.post('/v1/treatment/:id/medicine', async (req, res) => {
    try {
      const id = req.params['id'];
      const { sickle_id, disease_id, visit_no, drug_id, drug_value, frequency_id, frequency_value, duration, period_id, period_value, type, is_emergency, qty, incharge_mobile, incharge_hf_id, source } = req.body;
      // await sequelize.close();
      syncDatabase();
      const medicine = await MedicineModel.create({
        treatment_id: id,
        sickle_id,
        disease_id,
        visit_no,
        drug_id,
        drug_value,
        frequency_id,
        frequency_value,
        duration,
        period_id,
        period_value,
        type,
        is_emergency,
        qty,
        incharge_mobile,
        incharge_hf_id,
        source
      })
      if (medicine) {
        res.status(200).json({ message: 'Medicine added successfully', medicine_id: medicine.id });
      } else {
        res.status(404).json({ message: 'Medicine Data Missing' });
      }
    } catch (error) {
      console.error('Error creating Medicine:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  

module.exports = router;
