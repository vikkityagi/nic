const express = require('express');
const router = express.Router();
const TreatmentModel = require('../models/TreatmentModel');
const sequelize = require('../sequelize');

// Function to synchronize Sequelize with the database schema
async function syncDatabase() {
  try {
    await sequelize.sync({ force: false }); // Adjust force based on your needs
    console.log('Database synchronized successfully');
  } catch (error) {
    console.error('Error synchronizing database:', error);
    throw error; // Propagate the error if needed
  }
}


router.post('/v1/treatment', async (req, res) => {
    try {
      const { sickele_id, visit_no, disease_id, incharge_mobile, incharge_hf_id } = req.body;
      syncDatabase();
      const treatment = await TreatmentModel.create({
        sickele_id,
        visit_no,
        disease_id,
        incharge_mobile,
        incharge_hf_id,
      });
  
      if (treatment) {
        res.status(200).json({ message: 'Treatment Created Successfully', treatment_id: treatment.id })
      } else {
        res.status(404).json({ message: 'Treatment Data Missing' });
      }
    } catch (error) {
      console.error('Error creating treatment:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

module.exports = router;