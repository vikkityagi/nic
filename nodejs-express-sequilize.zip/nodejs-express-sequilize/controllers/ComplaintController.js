const express = require('express');
const router = express.Router();
const ComplaintModel = require('../models/ComplaintModel');

const sequelize = require('../sequelize');

// Function to synchronize Sequelize with the database schema
async function syncDatabase() {
    try {
      await sequelize.sync({ force: false }); // Adjust force based on your needs
      console.log('Database synchronized successfully');
    } catch (error) {
      console.error('Error synchronizing database:', error);
      throw error; // Propagate the error if needed
    }
  }

router.post('/v1/treatment/:id/complaint', async (req, res) => {
    try {
        const id = req.params['id'];
        const { sickele_id, visit_no, disease_id, symptom_value, since, period_id, period_value, type_id, type_value, is_emergency, incharge_mobile, incharge_hf_id, source } = req.body;
        syncDatabase();
        const complaint = await ComplaintModel.create({
            treatment_id: id,
            sickele_id,
            visit_no,
            disease_id,
            symptom_value,
            since,
            period_id,
            period_value,
            type_id,
            type_value,
            is_emergency,
            incharge_mobile,
            incharge_hf_id,
            source
        });
        if (complaint) {
            res.status(200).json({ message: 'Complaint Create successfully', complaint_id: complaint.id });
        } else {
            res.status(404).json({ message: 'Complaint Data Missing' });
        }
    } catch (error) {
        console.error('Error creating treatment:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});



router.put('/v1/treatment/:treatment_id/complaint/:complaint_id', async (req, res) => {
    try {
        const treatmentId = req.params['treatment_id'];
        const complaintId = req.params['complaint_id'];
        const { symptom_id, symptom_value, since, period_id, period_value, type_id, type_value, is_emergency, incharge_mobile, incharge_hf_id, source } = req.body;
        syncDatabase();
        const updatedData = {
            symptom_id,
            symptom_value,
            since,
            period_id,
            period_value,
            type_id,
            type_value,
            is_emergency,
            incharge_mobile,
            incharge_hf_id,
            source,
        };

        const editComplaint = await ComplaintModel.update(updatedData, { where: { id: complaintId, treatment_id: treatmentId } });
        console.log(editComplaint)
        if (editComplaint) {
            res.status(200).json({ message: 'Complaint Updated successfully', complaint_id: complaintId });
        } else {
            res.status(404).json({ message: 'Complaint not found' });
        }
    } catch (error) {
        console.error('Error creating treatment:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});

router.delete('/v1/treatment/:treatment_id/complaint/:complaint_id', async (req, res) => {
    try {
        const treatentId = req.params['treatment_id'];
        const complaintId = req.params['complaint_id'];
        syncDatabase();
        const deleteComplaint = await ComplaintModel.destroy({ where: { id: complaintId, treatment_id: treatentId } });
        if (deleteComplaint) {
            res.status(200).json({ message: 'Complaint deleted successfully', complaint_id: complaintId });
        } else {
            res.status(404).json({ message: 'Complaint not found' });
        }
    } catch (error) {
        console.error('Error delete in complaint:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }

})

module.exports = router;
