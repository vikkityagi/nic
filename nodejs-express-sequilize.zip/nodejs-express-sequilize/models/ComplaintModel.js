const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const Treatment = require('./TreatmentModel'); // Import the Treatment model


const ComplaintModel = sequelize.define('', {
  treatment_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Treatment,
      key: 'id',
    },
  },
  sickele_id: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  visit_no: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  disease_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  symptom_value: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  since: {
    type: DataTypes.DATEONLY, 
    allowNull: false,
  },
  period_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  period_value: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  type_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  type_value: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  is_emergency: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
    defaultValue: false,
  },
  incharge_mobile: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  incharge_hf_id: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  source: {
    type: DataTypes.STRING,
    allowNull: false,
  },
}, {
  tableName: 'complaint',
  timestamps: false,
});


ComplaintModel.belongsTo(Treatment, { foreignKey: 'treatment_id', targetKey: 'id' });


// sequelize.sync({force: false}).then(function(){
//   console.log("Table Complaint Created");
// }).catch(function(err){
//   console.error('Error creating database & tables:', err);
// })

module.exports = ComplaintModel;
