const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');

const TreatmentModel = sequelize.define('', {
  sickele_id: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  visit_no: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  disease_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  incharge_mobile: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  incharge_hf_id: {
    type: DataTypes.STRING,
    allowNull: false,
  },
}, {
  tableName: 'treatments',
  timestamps: false,
});

// sequelize.sync({ force: false })
//   .then(() => {
//     console.log('Table Treatment created!');
//   })
//   .catch(err => {
//     console.error('Error creating database & tables:', err);
//   });
  
module.exports = TreatmentModel;
