const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');// Adjust the path as per your project structure
const TreatmentModel = require('./TreatmentModel');

const MedicineModel = sequelize.define('', {
    treatment_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references:{
            model: TreatmentModel,
            key: 'id'
        }
    },
    sickle_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    disease_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    visit_no: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    drug_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    drug_value: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    frequency_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    frequency_value: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    duration: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    period_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    period_value: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    type: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    is_emergency: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
    },
    qty: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    incharge_mobile: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    incharge_hf_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    source: {
        type: DataTypes.STRING,
        allowNull: false,
    },
},
    {
        tableName: 'medicine',
        timestamps: true,
    });


MedicineModel.belongsTo(TreatmentModel, { foreignKey: 'treatment_id', targetKey: 'id' });


module.exports = MedicineModel;
