import { CommonModule } from '@angular/common';
import { Component, forwardRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';

@Component({
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatRadioModule],
  selector: 'app-color-picker',
  templateUrl: './color-picker.component.html',
  styleUrls: ['./color-picker.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => ColorPickerComponent),
      multi: true
    }
  ]
})
export class ColorPickerComponent {
  selectedColorControl = new FormControl();
  colors: string[] = ['#FF0000', '#00FF00', '#0000FF']; // Add more colors as needed

  selectedColor: any;

  onColorSelected(color: any) {
    this.selectedColor = color;
    document.body.style.backgroundColor = color; // Update the background color of the entire screen
  }

  constructor() { }

  writeValue(value: any) {
    this.selectedColorControl = value;
  }

  onChange: any = () => { };
  onTouch: any = () => { };

  selectColor(color: string) {
    this.selectedColorControl.setValue(color);
    this.selectedColor = color;
    this.onChange(this.selectedColorControl);
    this.onTouch();
  }

  registerOnChange(fn: any) {
    this.onChange = fn;
  }

  registerOnTouched(fn: any) {
    this.onTouch = fn;
  }

  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.key === 'ArrowRight') {
      event.preventDefault();
      const currentIndex = this.colors.indexOf(this.selectedColorControl.value);
      const nextIndex = (currentIndex + 1) % this.colors.length;
      this.selectedColorControl.setValue(this.colors[nextIndex]);
      this.onChange(this.selectedColorControl.value);
      this.onTouch();
    } else if (event.key === 'ArrowLeft') {
      event.preventDefault();
      const currentIndex = this.colors.indexOf(this.selectedColorControl.value);
      const previousIndex = (currentIndex - 1 + this.colors.length) % this.colors.length;
      this.selectedColorControl.setValue(this.colors[previousIndex]);
      this.onChange(this.selectedColorControl.value);
      this.onTouch();
    }
  }
  
}
